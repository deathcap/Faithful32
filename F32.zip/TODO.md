All the work that needs completing. 
===========================
Pull requests to expand this list are acceptable provided they are correct and include a link to the mod.
Any mods are welcome on this list, but mods in Feed The Beast packs are focused on.
Mods are expected to be organized alphanumerically and have some indication of already completed work.

Backpack			http://www.minecraftforum.net/topic/1492661-15x-16x-backpacks-v-12629/ (Complete, needs restyling)

Chisel				http://www.minecraftforum.net/topic/1749374-164smpforge-chisel/ (Minimal progress)

ExtraBees			http://extrabees.accudio.com/ (Partial, most textures done)

ExtraTiC			http://www.minecraftforum.net/topic/1985397-forge-extratic-tinkers-construct-metallurgy-add-on/ (Some progress, lots more to complete)

ExtraTrees			http://extratrees.accudio.com/ (No progress)

Forestry			http://forestry.sengir.net/wiki.new/doku.php (Partial, just needs some tree's, butterflies, some saplings)

JABBA				http://www.minecraftforum.net/topic/2182366-16x-jabba-103-just-another-better-barrel-attempt/ (Mostly done)

Mekanism			http://ci.aidancbrady.com/job/Mekanism/ (Build server link, website is not finished) (Some progress)

Metallurgy			http://www.minecraftforum.net/topic/744918-164forgesmp-metallurgy-putting-the-mine-back-in-minecraft/ (Most blocks done)

Natura				http://www.minecraftforum.net/topic/1753754-16xnatura/ (Some progress, lots more to complete)

OpenBlocks			http://www.minecraftforum.net/topic/1941514-16x-openblocks-122/ (No progress)

Power Converters		http://www.minecraftforum.net/topic/1695968-164-samrg472s-mods-powerconverters-alpha-builds/ (Some progress)

Project Red			http://projectredwiki.com/wiki/Main_Page (Some progress, lots more to complete)

Thermal Expansion		http://teamcofh.com/ (Partial, needs liquids, GUI's, strongboxes)

Tinkers Construct		http://www.minecraftforum.net/topic/1659892-164tinkers-construct/ (Partial, needs decoration blocks and liquids.

A list of quick projects if you would like to make a small contribution. These are not organized in any way, do whatever ones you want/can.

Flesh from Biomes O' Plenty

Mossy Skystone from Biomes O' Plenty

Border Stone from Extra Utilities

Heat Sand from Natura

Heat Glass from Natura

Tainted Soil from Natura

Berry Bushes from Natura

Strengthened Glass from Railcraft

Drawbridge from Tinkers Mechworks

Brownstone from Tinkers Construct

Strongboxes from Thermal Expansion 3

Drum from Extra Utilities

Mob Chunks from DartCraft

Ichorium Tools from Thaumic Tinker

Plates from IC2

Seedbags from IC2

All fluids from Tinkers Construct



