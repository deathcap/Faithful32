Faithful32
==========

License:

Not all works are original, a lot of things are reorganized to make them work with the latest versions of mods.
All textures are for use in playing Minecraft with mods or creating derivative works.
Combined, this means that you may use this pack or modify it in any way you see fit. You may not profit from its distribution.


Description:

Faithful with mods support: All textures done in Faithful32 style.

The original Faithful 32x32 Pack can be found here: http://www.minecraftforum.net/topic/72747-faithful-32x32-pack-updatemore-17-rose-bush-pufferfish-17/

The original pack is made by Vattic and a long list of helpers. Please look under the Credits section of his forum post I linked above.

This repository is a complete resource pack, you do not need to add this to vanilla Faithful 32x.


Downloading and Usage:

1) Download the latest pack from this site. http://www.magnificentbastards.net/faithful/

2) Run Minecraft, select "Options...", select "Texture Packs", select "Open texture pack folder".

3) Drag and drop the zip file into the texture pack folder.

4) Go back to Minecraft and select the Faithful 32x32 pack and you are done.